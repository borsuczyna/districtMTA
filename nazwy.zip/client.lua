local sx, sy = guiGetScreenSize()
local queue, queuePos;
local shaders = {}
local maskShaders = {}
local rts = {}
local found = {}
local current = {}
local visual = dxCreateShader("visual.fx", 0, 0, false, "all")
--engineApplyShaderToWorldTexture(visual, "stonesteps1")

for i = 1, 10 do
    local shader = dxCreateShader("shader.fx", 2)
    local maskShader = dxCreateShader("shader.fx", 1)
    local rt = dxCreateRenderTarget(sx, sy, true)
    shaders[i] = shader
    maskShaders[i] = maskShader
    rts[i] = rt
    dxSetShaderValue(shader, "secondRT", rt)
end

function processQueue()
    if not queue then return end

    for k,v in pairs(current) do
        local pixels = dxGetTexturePixels(v.rt, queuePos[1]-1, queuePos[2]-1, 2, 2)
        local r, g, b, a = dxGetPixelColor(pixels, 1, 1)
        if r > 50 then
            engineApplyShaderToWorldTexture(visual, v.name)
            table.insert(found, v.name)
        end
        engineRemoveShaderFromWorldTexture(v.maskShader, "*")
        engineRemoveShaderFromWorldTexture(v.shader, v.name)
    end

    current = {}

    if #queue == 0 then
        outputChatBox(table.concat(found, ", ") .. "    <    Copied to clipboard")
        setClipboard(table.concat(found, ", "))
        queue = nil
        return
    end

    for k,v in pairs(shaders) do
        local name = queue[1]

        if name then
            table.insert(current, {
                name = name,
                shader = v,
                rt = rts[k],
                maskShader = maskShaders[k]
            })
            table.remove(queue, 1)

            dxSetRenderTarget(rts[k], true)
            dxSetRenderTarget()

            engineApplyShaderToWorldTexture(v, name)
            engineApplyShaderToWorldTexture(maskShaders[k], "*")
            --engineRemoveShaderFromWorldTexture(maskShaders[k], name)
        end
    end
end

addEventHandler("onClientClick", root, function(btn, state, x, y)
    if btn ~= "left" or state ~= "down" then return end
    
    queuePos = {x, y}
    queue = {}
    current = {}
    found = {}

    engineRemoveShaderFromWorldTexture(visual, "*")

    for k,v in pairs(engineGetVisibleTextureNames()) do
        table.insert(queue, v)
    end

    processQueue()
end)

addEventHandler("onClientRender", root, function()
    processQueue()
end)

--[[local shader = dxCreateShader("shader.fx", 2)
local shader2 = dxCreateShader("shader.fx", 1)
local rt = dxCreateRenderTarget(sx, sy, true)
dxSetShaderValue(shader, "secondRT", rt)
dxSetShaderValue(shader2, "secondRT", rt)
dxSetShaderValue(shader2, "hidden", true)
engineApplyShaderToWorldTexture(shader2, "*")
engineApplyShaderToWorldTexture(shader, "snpedtest1")

addEventHandler("onClientPreRender", root, function()
    dxSetRenderTarget(rt, true)
    dxSetRenderTarget()
end)

addEventHandler("onClientRender", root, function()
    dxDrawImage(0, 0, sx, sy, rt)
end)]]



bindKey("F3", "down", function()
	if myszka== true then
		myszka = false
        showCursor(false)
	else
        myszka = true
        showCursor(true)
	end
end)